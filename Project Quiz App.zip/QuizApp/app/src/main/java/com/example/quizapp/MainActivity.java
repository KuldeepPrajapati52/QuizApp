package com.example.quizapp;

import androidx.appcompat.app.AppCompatActivity;
import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    RadioGroup radioGroupOne, radioGroupTwo;
    RadioButton firstQRans, firstQWans, secondQWans, secondQRans;
    EditText thirdQans, fourQans, nameT;
    CheckBox fiveCheckBoxOneR, fiveCheckBoxTwoR, fiveCheckBoxThreeW, fiveCheckBoxFourW, sixCheckBoxOneR, sixCheckBoxTwoW, sixCheckBoxThreeW, sixCheckBoxFourR;
    Button clearAnswer, submitAnswer;
    int finalScore = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        radioGroupOne = (RadioGroup) findViewById(R.id.radioGroup_One);
        firstQRans = (RadioButton) findViewById(R.id.right_question_one);
        firstQWans = (RadioButton) findViewById(R.id.wrong_question_one);
        radioGroupTwo = (RadioGroup) findViewById(R.id.radioGroup_Two);
        secondQWans = (RadioButton) findViewById(R.id.wrong_question_two);
        secondQRans = (RadioButton) findViewById(R.id.right_question_two);
        thirdQans = (EditText) findViewById(R.id.question_three);
        fourQans = (EditText) findViewById(R.id.question_four);
        fiveCheckBoxOneR = (CheckBox) findViewById(R.id.question_five_one);
        fiveCheckBoxTwoR = (CheckBox) findViewById(R.id.question_five_two);
        fiveCheckBoxThreeW = (CheckBox) findViewById(R.id.question_five_three);
        fiveCheckBoxFourW = (CheckBox) findViewById(R.id.question_five_four);
        sixCheckBoxOneR = (CheckBox) findViewById(R.id.question_six_one);
        sixCheckBoxTwoW = (CheckBox) findViewById(R.id.question_six_two);
        sixCheckBoxThreeW = (CheckBox) findViewById(R.id.question_six_three);
        sixCheckBoxFourR = findViewById(R.id.question_six_four);
        submitAnswer = findViewById(R.id.submit_answer);
        clearAnswer = findViewById(R.id.clear_answer);

        //Submit Button

        submitAnswer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String thirdQ = thirdQans.getText().toString();
                String fourQ = fourQans.getText().toString();
                if (fiveCheckBoxOneR.isChecked() && fiveCheckBoxTwoR.isChecked()) {
                    finalScore += 1;
                    displayScore(finalScore);
                }
                if (fiveCheckBoxOneR.isChecked() && fiveCheckBoxTwoR.isChecked() && fiveCheckBoxThreeW.isChecked() || fiveCheckBoxOneR.isChecked() && fiveCheckBoxTwoR.isChecked() && fiveCheckBoxFourW.isChecked() || fiveCheckBoxOneR.isChecked() && fiveCheckBoxTwoR.isChecked() && fiveCheckBoxThreeW.isChecked() && fiveCheckBoxFourW.isChecked()) {
                    finalScore -= 1;
                    displayScore(finalScore);
                }
                if (sixCheckBoxOneR.isChecked() && sixCheckBoxFourR.isChecked()) {
                    finalScore += 1;
                    displayScore(finalScore);
                }
                if(sixCheckBoxOneR.isChecked() && sixCheckBoxTwoW.isChecked() && sixCheckBoxFourR.isChecked() || sixCheckBoxOneR.isChecked() && sixCheckBoxThreeW.isChecked() && sixCheckBoxFourR.isChecked()|| sixCheckBoxOneR.isChecked() && sixCheckBoxTwoW.isChecked() && sixCheckBoxThreeW.isChecked() && sixCheckBoxFourR.isChecked() ) {
                    finalScore -=1;
                    displayScore(finalScore);
                }
                if(firstQRans.isChecked()){
                    finalScore += 1;
                    displayScore(finalScore);
                }
                if(secondQRans.isChecked()){
                    finalScore += 1;
                    displayScore(finalScore);
                }
                if(thirdQ.equalsIgnoreCase("Vatican City")){
                    finalScore += 1;
                    displayScore(finalScore);
                }
                if(fourQ.equalsIgnoreCase("Uttar Pradesh")){
                    finalScore += 1;
                   displayScore(finalScore);
                 }
                else {
                    displayScore(finalScore);
                }
            }
        });

        //Reset Button
        clearAnswer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (firstQRans.isChecked()) {
                    firstQRans.setChecked(false);
                }
                if (firstQWans.isChecked()) {
                    firstQWans.setChecked(false);
                }
                if (secondQRans.isChecked()) {
                    secondQRans.setChecked(false);
                }
                if (secondQWans.isChecked()) {
                    secondQWans.setChecked(false);
                }
                thirdQans.setText("");
                fourQans.setText("");
                if (fiveCheckBoxOneR.isChecked()) {
                    fiveCheckBoxOneR.setChecked(false);
                }
                if (fiveCheckBoxTwoR.isChecked()) {
                    fiveCheckBoxTwoR.setChecked(false);
                }
                if (fiveCheckBoxThreeW.isChecked()) {
                    fiveCheckBoxThreeW.setChecked(false);
                }
                if (fiveCheckBoxFourW.isChecked()) {
                    fiveCheckBoxFourW.setChecked(false);
                }
                if (sixCheckBoxOneR.isChecked()) {
                    sixCheckBoxOneR.setChecked(false);
                }
                if (sixCheckBoxTwoW.isChecked()) {
                    sixCheckBoxTwoW.setChecked(false);
                }
                if (sixCheckBoxThreeW.isChecked()) {
                    sixCheckBoxThreeW.setChecked(false);
                }
                if (sixCheckBoxFourR.isChecked()) {
                    sixCheckBoxFourR.setChecked(false);
                }
                finalScore = 0;
                displayScoreR(finalScore);

            }
        });

    }

    private void displayScoreR(int finalScore) { TextView quantityTextView = (TextView) findViewById(R.id.score_view);
        quantityTextView.setText("Score : Not Yet Submitted!");
        submitAnswer.setClickable(true);
        //Toast
        Context context = getApplicationContext();
        CharSequence text = "Resetted!";
        int duration = Toast.LENGTH_SHORT;

        Toast toast = Toast.makeText(context, text, duration);
        toast.show();


    }

    //Display
    private void displayScore(int finalScore) {
        TextView quantityTextView = (TextView) findViewById(R.id.score_view);
        quantityTextView.setText("Final Score : " + finalScore + " Out Of 6");
        submitAnswer.setClickable(false);
        //Toast
        Context context = getApplicationContext();
        CharSequence text = "Check Your Score!";
        int duration = Toast.LENGTH_SHORT;

        Toast toast = Toast.makeText(context, text, duration);
        toast.show();


    }


}

